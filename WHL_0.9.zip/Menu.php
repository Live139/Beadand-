<?php
	include 'config.php';
	$active = 'class="active"';
	$Home = '';
	$Stream = '';
	$Galeria = '';
	$Regist = '';
	switch ($GLOBALS['site']){
		case 0:
			$Home = $active;
			break;
		case 1:
			$Stream = $active;
			break;
		case 2:
			$Galeria = $active;
			break;			
		case 3:
			$Regist = $active;
			break;
	}
	if ($login == 1) {
		include 'Logout.php';
		$u_id = $_COOKIE['uid'];
		$getinfo = mysqli_query($conn,"SELECT * FROM users WHERE u_id = $u_id");
		$arr = mysqli_fetch_array($getinfo);
		echo "Bejelentkezve mint: <br>".$arr["u_fname"]." ".$arr["u_lname"];
	}else{
		include 'Login.php';
	}
 ?>

