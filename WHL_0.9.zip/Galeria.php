<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="/Images/WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<title>WE HAVE LATE</title>
		<?php $site = 2;?>
	</head>
	
	<body>
		<div class="menu">
			<?php include 'Menu.php';?>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="/Images/WHL_logo.png" alt="WHL logo">
		<h1>WE HAVE LATE</h1>
		<div class="row"> 
			<div class="column">
				<img src="/Images/GDragon.jpg">
				<img src="/Images/GNyarLAN.jpg">
				<img src="/Images/GNyarLAN1.jpg">
				<img src="/Images/GPillow.jpg">
				<img src="/Images/GSiege.jpg">
				<img src="/Images/GSledge.jpg">
				<img src="/Images/GTelLAN.jpg">
			</div>
			<div class="column">
				<img src="/Images/GTelLAN1.jpg">
				<img src="/Images/GTelLAN2.jpg">
				<img src="/Images/GPillow.jpg">
				<img src="/Images/GSiege.jpg">
				<img src="/Images/GSledge.jpg">
				<img src="/Images/GTelLAN.jpg">
			</div> 
			<div class="column">
				<img src="/Images/GDragon.jpg">
				<img src="/Images/GNyarLAN.jpg">
				<img src="/Images/GNyarLAN1.jpg">
				<img src="/Images/GTelLAN1.jpg">
				<img src="/Images/GTelLAN2.jpg">
				<img src="/Images/GPillow.jpg">
				<img src="/Images/GSiege.jpg">
			</div>
			<div class="column">
				<img src="/Images/GTelLAN1.jpg">
				<img src="/Images/GTelLAN2.jpg">
				<img src="/Images/GPillow.jpg">
				<img src="/Images/GSiege.jpg">
				<img src="/Images/GSledge.jpg">
				<img src="/Images/GTelLAN.jpg">
			</div>
		</div>
		<footer>
			<hr>
			<p>Az oldalt készítette: Balogh Levente <br>Az eredeti holap megtekinthető itt:<a href="https://teamwhl.home.blog">teamwhl.home.blog</a></p>
		</footer>
		</div>
		<div id="SidePic">
			<img src="/Images/Tracer.jpg" alt="Overwatch">
		</div>
	</body>
</html>
