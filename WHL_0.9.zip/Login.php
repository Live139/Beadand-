<?php
		include 'config.php';
		
		if (isset($_POST["l_btn"])){
				$u_lname = $_POST['u_lname'];
				$u_pass = $_POST['u_pass'];
				if (empty($u_lname) || empty($u_pass)){
					echo "Kérlek töltsd ki az összes mezőt";
				}else{
					$selectfdb = mysqli_query($conn,"SELECT * FROM users WHERE u_lname = '$u_lname' AND u_pass = '$u_pass'");
					$row = mysqli_fetch_array($selectfdb);
					if ($row["u_lname"] == $u_lname && $row["u_pass"] == $u_pass){
						setcookie('uid',$row["u_id"],time() + (3600 * 24));
						setcookie('login',1,time() + (3600 * 24));
						echo " <meta http-equiv='refresh' content='0; url=index.php'>";
					}else {
						echo "Felhasználónév vagy jelszó hibás";
					}
				}
			} 
	echo '<a href="index.php"'. $Home .'><b>Főoldal</b></a>
	<a href="Stream.php"'. $Stream .'><b>Stream</b></a>
	<a href="Galeria.php"'. $Galeria .'><b>Galéria</b></a>
	<a href="Regist.php"'. $Regist .'><b>Regisztráció</b></a>
	<div class="topnav">
		<div class="search-container">
			<form action="https://www.google.com/search" mothod="get">
			<input type="text" name="q" placeholder="Keresés..">
			<button type="submit" value="Keresés.."><i class="fa fa-search"></i></button>
    </form>
		</div>
	</div>
	<button class="open-button" onclick="openForm()"><b>'. $log .'</b></button>
	<div class="form-popup" id="myForm">
		<form action="" method="post" class="form-container">
			<h1>Belépés</h1>

			<label><b>Kereszt név:</b></label>
			<input type="text" placeholder="Add meg a kereszt neved" name="u_lname" required>
		
			<label><b>Jelszó</b></label>
			<input type="password" placeholder="Üsd be a jelszavad" name="u_pass" required>
	
			<button type="submit" name="l_btn" class="btn">Belépés</button>
			<button type="button" class="btn cancel" onclick="closeForm()">Vissza</button>
		</form>
	</div>
	<script>
		function openForm() {
			document.getElementById("myForm").style.display = "block";
		}

		function closeForm() {
			document.getElementById("myForm").style.display = "none";
		}
	</script>';
?>























