<?php
if (isset($_POST["l_btn"])){
	setcookie('uid',' ',time() + (3600 * 24));
	setcookie('login',0,time() + (3600 * 24));
	echo " <meta http-equiv='refresh' content='0; url=index.php'>";
}
	echo '<a href="index.php"'. $Home .'><b>Főoldal</b></a>
	<a href="Stream.php"'. $Stream .'><b>Stream</b></a>
	<a href="Galeria.php"'. $Galeria .'><b>Galéria</b></a>
	<a href="Regist.php"'. $Regist .'><b>Regisztráció</b></a>
	<div class="topnav">
		<div class="search-container">
			<form action="https://www.google.com/search" mothod="get">
			<input type="text" name="q" placeholder="Keresés..">
			<button type="submit" value="Keresés.."><i class="fa fa-search"></i></button>
    </form>
		</div>
	</div>
	<button class="open-button" onclick="openForm()"><b>'. $log .'</b></button>
	<div class="form-popup" id="myForm">
		<form action="" method="post" class="form-container">
			<button type="submit" name="l_btn" class="btn">Kilépés</button>
			<button type="button" class="btn cancel" onclick="closeForm()">Vissza</button>
		</form>
	</div>
	<script>
		function openForm() {
			document.getElementById("myForm").style.display = "block";
		}

		function closeForm() {
			document.getElementById("myForm").style.display = "none";
		}
	</script>';
?>