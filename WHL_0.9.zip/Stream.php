<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="/Images/WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<title>WE HAVE LATE</title>
		<?php $site = 1;?>
	</head>
	
	<body>
		<div class="menu">
			<?php include 'Menu.php';?>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="/Images/WHL_logo.png" alt="WHL logo">
		<h1>WE HAVE LATE</h1>
		<table>
			<tr>
				<th>
					<h3>Sir Gold3n</h3>
					<p>Qualiti playek, quantity gamek. Kell ennél több? Én ugyan nem vagyok streamer de itt a tetyám Rozsombi twitch-e, ha van időd csekkold és kövesd a csiti csatit.<br>
					<a href="https://www.twitch.tv/rozsombi"><img id="Icon" src="/Images/Twitch.png" alt="Twitch">twitch.tv/rozsombi</a></p>
				</th>
				<td><iframe width="560" height="315" 
					src="https://www.youtube.com/embed/izTZivYJGOg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
					</iframe></td>
			</tr>
			<tr>
				<th>
					<h3>Dobroboost</h3>
					<p>Sziasztok Dávid vagyok (21), gamer és hatalmas paintmester. Általában online játékokkal játszok, és a következőkkel:
						<li>FIFA19(pc)</li>
						<li>LoL</li>
						<li>HS</li>
						<li>PubG</li>és bármi más ami épp a kezeim közé kerül.<br>
					<a href="https://www.twitch.tv/dobrovicztv"><img id="Icon" src="/Images/Twitch.png" alt="Twitch">twitch.tv/dobrovicztv</a></p>
				</th>
				<td><iframe width="560" height="315" 
					src="https://www.youtube.com/embed/Y8WC87Qc4ZM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
					</iframe></td>
			</tr>
			<tr>
				<th>
					<h3>Fight4YourLife</h3>
					<p>Sziasztok.A nevem Tamás, 20 éves, szeretek gamelni, szeretnék 1 összetartó közösséget felépíteni, új embereket megismerni és élményeket szerezni a Twitchel.Streamek nagyjából minden napra várhatók egyenlőre nincsenek pontos időpontok. Szeretettel várok mindenkit a stream chatre ott tali, Sziasztok!<br>
					<a href="https://www.twitch.tv/fight4yourlife99"><img id="Icon" src="/Images/Twitch.png" alt="Twitch">twitch.tv/fight4yourlife99</a></p>
				</th>
				<td>
					<video width="560" height="315" controls>
						<source src="/Videos/F4YL.mp4" type="video/mp4">
					</video>
			</tr>
			<tr>
				<th>
					<h3>Live139</h3>
					<p>Streamek ritkán de akkor minden mennyiségben. Ha szereted a motorsport szimulátorokat vagy a lol-t akkor itt helyed. Találkozunk a stream-en.<br>
					<a href="https://www.twitch.tv/live139"><img id="Icon" src="/Images/Twitch.png" alt="Twitch">twitch.tv/live139</a></p>
					
				</th>
				<td>
					<iframe width="560" height="315" 
					src="https://www.youtube.com/embed/2n3u1obE2dk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
					</iframe></td>
					
			</tr>		
		</table>
		<footer>
			<hr>
			<p>Az oldalt készítette: Balogh Levente <br>Az eredeti holap megtekinthető itt:<a href="https://teamwhl.home.blog">teamwhl.home.blog</a></p>
		</footer>
		</div>
		<div id="SidePic">
			<img src="/Images/Rek'sai.jpg" alt="League of Legends">
		</div>
	</body>
</html>
