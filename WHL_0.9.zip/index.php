<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="/Images/WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<title>WE HAVE LATE</title>
		<?php $site = 0;?>
	</head>
	
	<body>
		<div class="menu">
			<?php include 'Menu.php';?>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="/Images/WHL_logo.png" alt="WHL logo">
		<h1>WE HAVE LATE</h1>
		<hr>
		<h3>A csapatról:</h3>
		<p>A HWL egy gamer klub ami 2013-alapult DobroboostWHL jóvoltából. Eleinte csak egy 5 fős csapatot szerettünk volna létrehozni hogy részt vegyünk különböző League of Legedns versenyeken. Ahogy bővült a baráti társaságunk úgy népesedett a csapat is és így végül egy klubbá nőttük ki magunkat.</p>
		<p>Ha te is csatlakozni szeretnál kis csapatunkba akkor a regisztrálás követően ezt bármikor megteheted. :D</p>
		<h3>Feltételek:</h3>
		<ul>
			<li>Legyél minimum 16 éves.</li>
			<li>Mutass hajlandóságot a fejlődésre és csapatmunkára.</li>
			<li>Legyél rage proof (legalábbis ne az első miss play-re lépj ki).</li>
			<li>Fontosabb mecsen esetén Team speak használata!</li>
		<ul>
		<footer>
			<hr>
			<p>Az oldalt készítette: Balogh Levente <br>Az eredeti holap megtekinthető itt:<a href="https://teamwhl.home.blog">teamwhl.home.blog</a></p>
		</footer>
		</div>
		<div id="SidePic">
			<img src="/Images/Ela.jpg" alt="Rainbow 6 Siege">
		</div>
	</body>
</html>
