<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<title>WE HAVE LATE</title>
	</head>
	
	<body>
		<div class="menu">
			<a href="Home.php" class="active">Főoldal</a>
			<a href="Stream.php">Stream</a>
			<a href="Galeria.php">Galéria</a>
			<a href="Forum.php">Fórum</a>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="WHL_logo.png" alt="WHL logo">
		<h1>Team WHL</h1>
		<hr>
		<h2>WE HAVE LATE</h2>
		<p>A HWL egy gamer klub ami 2013-alapult DobroboostWHL jóvoltából. Eleinte csak egy 5 fős csapatot szerettünk volna létrehozni hogy részt vegyünk különböző League of Legedns versenyeken. Ahogy bővült a baráti társaságunk úgy népesedett a csapat is és így végül egy klubbá nőttük ki magunkat.</p>
		</div>
		<div id="SidePic">
			<img src="Ela.jpg" alt="Rainbow 6 Siege">
		</div>
	</body>
</html>
