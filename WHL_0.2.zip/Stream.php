<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<title>WE HAVE LATE</title>
	</head>
	
	<body>
		<div class="menu">
			<a href="Home.php">Főoldal</a>
			<a href="Stream.php" class="active">Stream</a>
			<a href="Galeria.php">Galéria</a>
			<a href="Forum.php">Fórum</a>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="WHL_logo.png" alt="WHL logo">
		<h1>Team WHL</h1>
		<hr>
		<h2>WE HAVE LATE</h2>
		
		</div>
		<div id="SidePic">
			<img src="Rek'sai.jpg" alt="League of Legends">
		</div>
	</body>
</html>
