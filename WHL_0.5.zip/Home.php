<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="/Images/WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<title>WE HAVE LATE</title>
		<?php $site = 0;?>
	</head>
	
	<body>
		<div class="menu">
			<?php include 'Menu.php';?>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="/Images/WHL_logo.png" alt="WHL logo">
		<h1>WE HAVE LATE</h1>
		<hr>
		<p>A HWL egy gamer klub ami 2013-alapult DobroboostWHL jóvoltából. Eleinte csak egy 5 fős csapatot szerettünk volna létrehozni hogy részt vegyünk különböző League of Legedns versenyeken. Ahogy bővült a baráti társaságunk úgy népesedett a csapat is és így végül egy klubbá nőttük ki magunkat.</p>
		<p>Ha te is csatlakozni szeretnál kis csapatunkba akkor a regisztrálás követően ezt bármikor megteheted. :D</p>
		</div>
		<div id="SidePic">
			<img src="/Images/Ela.jpg" alt="Rainbow 6 Siege">
		</div>
	</body>
</html>
