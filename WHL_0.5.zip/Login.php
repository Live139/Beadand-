<?php
		include 'config.php';
		if (isset($_POST["l_btn"])){
				$u_lname = $_POST['u_lname'];
				$u_pass = $_POST['u_pass'];
				if (empty($u_lname) || empty($u_pass)){
					echo "Kérlek töltsd ki az összes mezőt";
				}else{
					$selectfdb = mysqli_query($conn,"SELECT * FROM users WHERE u_lname = '$u_lname' AND u_pass = '$u_pass'");
					$row = mysqli_fetch_array($selectfdb);
					if ($row["u_lname"] == $u_lname && $row["u_pass"] == $u_pass){
						echo "Bejelentkezve mint: ".$row["u_lname"];
						setcookie('uid',$row["u_id"],time() + (3600 * 24));
						setcookie('login',1,time() + (3600 * 24));
						echo " <meta http-equiv='refresh' content='0; url=Home.php'>";
					}else {
						echo "Felhasználónév vagy jelszó hibás";
					}
				}
			}
?>