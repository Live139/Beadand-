<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="/Images/WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<title>WE HAVE LATE</title>
		<?php $site = 3;?>
	</head>
	
	<body>
		<div class="menu">
			<?php include 'Menu.php';?>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="/Images/WHL_logo.png" alt="WHL logo">
		<h1>WE HAVE LATE</h1>

		<?php
		include 'config.php';
		
		if (isset($_POST["u_btn"])){
			$u_fname = $_POST["u_fname"];
			$u_lname = $_POST["u_lname"];
			$u_pass = $_POST["u_pass"];
			if (empty($u_fname) || empty($u_lname) || empty($u_pass)){
				echo "Kérlek töltsd ki az összes mezőt!";
			}else{
				$selectfdb = mysqli_query($conn,"SELECT * FROM users WHERE u_lname = '$u_lname' AND u_fname = '$u_fname'");
				$row = mysqli_fetch_array($selectfdb);
				if ($row["u_fname"] == $u_fname && $row["u_lname"] == $u_lname){
					echo "A felhasználó név már foglalt";
				}else{
					$insert = mysqli_query($conn,"INSERT INTO `users` (`u_fname`, `u_lname`, `u_pass`) VALUES ('$u_fname', '$u_lname', '$u_pass')");
					echo "Sikeres adat bevitel.";
					}
			}
		}
		?>
		
		<form action="Regist.php" method="post">
			<h2>Regisztráció</h2>
				<p>Kérlek töltsd ki a mezőket hogy regisztrálni tudj.</p>
				<hr>
			<label><b>Vezeték Név:</b></label>
			<input type="text" placeholder="Add meg a vezeték neved" name="u_fname" value=""><br>
			<label><b>Kereszt Név:</b></label>
			<input type="text" placeholder="Add meg a kereszt neved" name="u_lname" value=""><br>
			<label><b>Jelszó:</b></label>
			<input type="password" placeholder="Add meg a jelszavad" name="u_pass" value=""><br>
			
			<div class="clearfix">
					<a href="Home.php"><button type="button" class="cancelbtn">Vissza</button></a>
					<button type="submit" name="u_btn" class="signupbtn">Regisztrálok</button>
			</div>
		</form>
		
		</div>
		<div id="SidePic">
			<img src="/Images/pubg.jpg" alt="Player Unkonw Battleground">
		</div>
	</body>
</html>
