<?php
	$active = 'class="active"';
	$Home = '';
	$Stream = '';
	$Galeria = '';
	$Regist = '';
	switch ($GLOBALS['site']){
		case 0:
			$Home = $active;
			break;
		case 1:
			$Stream = $active;
			break;
		case 2:
			$Galeria = $active;
			break;			
		case 3:
			$Regist = $active;
			break;
	}
	echo '<a href="Home.php"'. $Home .'><b>Főoldal</b></a>
	<a href="Stream.php"'. $Stream .'><b>Stream</b></a>
	<a href="Galeria.php"'. $Galeria .'><b>Galéria</b></a>
	<a href="Regist.php"'. $Regist .'><b>Regisztráció</b></a>
	<button class="open-button" onclick="openForm()"><b>Belépés</b></button>
	<div class="form-popup" id="myForm">
		<form action="" method="post" class="form-container">
			<h1>Belépés</h1>

			<label><b>Kereszt név</b></label>
			<input type="text" placeholder="Kereszt név" name="u_lname" required>

			<label><b>Jelszó</b></label>
			<input type="password" placeholder="Üsd be a jelszavad" name="u_pass" required>

			<button type="submit" name="l_btn" class="btn">Belépés</button>
			<button type="button" class="btn cancel" onclick="closeForm()">Vissza</button>
		</form>
	</div>
	<script>
		function openForm() {
			document.getElementById("myForm").style.display = "block";
		}

		function closeForm() {
			document.getElementById("myForm").style.display = "none";
		}
	</script>
	';
	include 'Login.php';
 ?>

