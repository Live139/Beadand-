<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/x-icon" href="/Images/WHLIcon.png" />
		<link rel="stylesheet" type="text/css" href="style.css">
		<title>WE HAVE LATE</title>
		<?php $site = 2;?>
	</head>
	
	<body>
		<div class="menu">
			<?php include 'Menu.php';?>
		</div>
		<div class="clear"></div>
		<div class="main">
		<img id="logo" src="/Images/WHL_logo.png" alt="WHL logo">
		<h1>WE HAVE LATE</h1>
		
		</div>
		<div id="SidePic">
			<img src="Tracer.jpg" alt="/Images/Overwatch">
		</div>
	</body>
</html>
